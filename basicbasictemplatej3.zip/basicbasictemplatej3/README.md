BasicBasicTemplate
==================

My very basic Joomla! template

Please note this is a Joomla! 3 compatible template
